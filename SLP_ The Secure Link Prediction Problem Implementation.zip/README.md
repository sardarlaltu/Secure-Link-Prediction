==========================================================
Process to Run the codes:
==========================================================
Step 1: Install PBC library
Step 2: Install supporting Libraries; m4, flex, bison etc.
Step 3: Install GNU library if required
Step 4: Run myBGN_test to check whether the above library installed properly or not
Step 5: Give graph data file in the data folder. 
STEP 6: Update data file path, number of nodes and security bits in makefile
STEP 7: Run SLP1 by  "make slp1"
STEP 8: Run SLP2 by  "make slp2"

==========================================================
